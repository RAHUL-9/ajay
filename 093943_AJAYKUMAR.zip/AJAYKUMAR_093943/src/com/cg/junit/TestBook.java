package com.cg.junit;

import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bean.Book;
import com.cg.service.BookCollectionHelper;

public class TestBook {
	static BookCollectionHelper help;
	static Book book;
	
	
//declaration of BeforeClass	
	@BeforeClass
	public static void init()
	{
		help=new BookCollectionHelper();
		book=new Book();
		
	}
	
	//creation of Test cases testAddBook() 
	@Test
	public void testAddBook() 
	{
		int length=help.getTotalBookCount();
		book.setBookId(123);
		book.setBookName("java11");
		book.setBookPrice(250.00f);
		help.addBookDetails(book);
		assertTrue(help.getTotalBookCount()>length);
		
	}
	
	//creation of Test cases testCountToBook() 
	@Test
	public void testCountToBook() 
	{
		assertTrue(help.getTotalBookCount()>=2);
		
	}

	//creation of Test cases getBookId()
	@Test
	public void getBookId()
	{
		book.setBookId(125);
		int val=book.getBookId();
		assertTrue(val==125);
		
	}
	
	//creation of Test cases InvalidBookId()
	@Test
	public void InvalidBookId()
	{
		book.setBookId(123);
		int val=book.getBookId();
		assertNotSame(val,125);
		
	}
	
	//creation of Test cases InvalidTestCountToBook()
	@Test
	public void InvalidTestCountToBook()
	{
		int length=help.getTotalBookCount();
		book.setBookId(124);
		book.setBookName("java12");
		book.setBookPrice(350.00f);
		help.addBookDetails(book);
		assertNotEquals(2, help.getTotalBookCount()>length);
		
	}

	//declaration of AfterClass	
	@AfterClass
	public static void destroy()
	{
		help=null;
	}
	
	

}
