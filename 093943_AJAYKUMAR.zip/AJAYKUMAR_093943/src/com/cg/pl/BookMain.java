package com.cg.pl;

import java.util.Scanner;

import com.cg.bean.Book;
import com.cg.exception.BookException;
import com.cg.service.BookCollectionHelper;
import com.cg.service.BookValidator;


public class BookMain {
	
	static Scanner scan = new Scanner(System.in);
	static BookValidator bookval=new BookValidator();

	public static void main(String[] args)
	{
		menu();
	
	}
//menu() function will accept the user input to select the operations
	private static void menu() 
	{
		
		String ch =null;
		System.out.println("1.Add new Books");
		System.out.println("2.Find total numbers of Books");
		System.out.println("3.Exit");
		while(true)
		{
	try
	{
		System.out.println("Enter your choice : ");
        ch=scan.next();
        bookval.isValidChoice(ch);
	}
	catch(BookException exp)
	{
		System.err.println(exp.getMessage());
		continue;
	}
	break;
	}
		switch (ch)
		{
		case "1":
			addBookRecords();
			break;
		case "2":
			int count= new BookCollectionHelper().getTotalBookCount();
			System.out.println("Total number of books available is :"+" "+count);
			break;
			
		case "3":
			System.out.println("-----Exit-----");
			break;	
		default:
			System.err.println("Please enter the correct choice :");
			System.out.println("---------------------------------");
			menu();
		}	
		}
		
	
	// addBookRecords() will accept the number of records user want to insert
	public static void addBookRecords()
	{
		System.out.println("How many book records you want :");
		int num=scan.nextInt();
		int n=num;
		if(num>0 && num!=0)
		{
		while(num!=0)
		{
		int bookId=acceptBookId();
		String bookName=acceptBookName();
		float bookPrice=acceptBookPrice();
		Book b=new Book(bookId,bookName,bookPrice);
		new BookCollectionHelper().addBookDetails(b);
		num--;
		}
		System.out.println(n+" "+"Books are added successfully in the Inventory.");
		System.out.println("-----------------------");
		menu();
		}
		else
		{
		  System.err.println("Failed to add new books.");
		  addBookRecords();
		}
		
	}
	
	//acceptBookId() will accept the bookId
	public static int acceptBookId()
	{
		int bookId=0;
		try
		{
		System.out.println("Enter Book Id :");
		bookId=scan.nextInt();
		bookval.isValidBookId(bookId);
		}
		catch(BookException exp)
		{
			System.err.println(exp.getMessage());
			acceptBookId();
		}
		return bookId;
	}
	
	//acceptBookName() will accept the bookName
	public static String acceptBookName()
	{
		String bookName=null;
		try
		{
		System.out.println("Enter Book Name :");
		bookName=scan.nextLine();
		bookval.isValidBookName(bookName);
		}
		catch(BookException exp)
		{
			System.err.println(exp.getMessage());
			acceptBookName();
		}
		return bookName;
	}
	
	//acceptBookPrice() will accept the bookPrice
	public static float acceptBookPrice()
	{
		float bookPrice = 0;
		try
		{
		System.out.println("Enter Book Price :");
		bookPrice=scan.nextFloat();
		bookval.isValidBookPrice(bookPrice);
		}
		catch(BookException exp)
		{
			System.err.println(exp.getMessage());
			acceptBookPrice();
		}
		return bookPrice;
	}
	
	

}
