package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.exception.BookException;

public class BookValidator {
	
	//creation of validation for valid choice
	public boolean isValidChoice(String ch ) throws BookException
	{
		boolean flag=false;
		
		Pattern pat_ch=Pattern.compile("^[1-9]{1}$");
		Matcher mat_ch=pat_ch.matcher(ch);
		if(!mat_ch.find())
		{
			throw new BookException("Choice should  be from above choice ");
		}
		return flag;
	}	
	
	//creation of validation for valid Book Id
	public boolean isValidBookId(int bookId ) throws BookException
	{
		boolean flag=false;
		
		Pattern pat_id=Pattern.compile("^[0-9]{3}$");
		Matcher mat_id=pat_id.matcher(String.valueOf(bookId));
		if(!mat_id.find())
		{
			throw new BookException("Book id should be in 3 digits only");
		}
		return flag;
	}	
	
	//creation of validation for valid Book Name
	public boolean isValidBookName(String bookName) throws BookException
	{
		boolean flag=false;
		
	    Pattern pat_name=Pattern.compile("^[[\\s]*[\\S]*]{5,40}$");
		Matcher mat_name=pat_name.matcher(bookName);
		if(!mat_name.find())
		{
			throw new BookException("Book name should be in  alphanumeric");
		}
		return flag;
	}
	
	//creation of validation for valid Book Price
	public boolean isValidBookPrice(Float bookPrice) throws BookException
	{
		boolean flag=false;
		
		Pattern pat_price=Pattern.compile("^[0-9]{0,9}.[0-9]{0,2}$");
		Matcher mat_price=pat_price.matcher(String.valueOf(bookPrice));
		if(!mat_price.find())
		{
			throw new BookException("Book price should be in float format");
		}
		if(bookPrice>1000.00f)
		{
			throw new BookException("Book price should be not be more than 1000");
		}
		return flag;
		
	}
	
	

	
	
}
