function isNumber()
{
	
	num=parseInt(document.getElementById("txtNum").value);
	if(num!=0)
	{
		return true;
	}
	else
	{
	alert("Please enter valid employee number");
	return false;
	}
}
function isName()
{
	name=document.getElementById("txtName").value;
	if( name!="" && name.length<=30)
	{
		
		return true;
	}
	else
	{
	alert("Please enter employee name");
	return false;
	}
}
	function total()
	{
		mpt_marks=parseInt(document.getElementById("mpt").value);
		mtt_marks=parseInt(document.getElementById("mtt").value);
		assign_marks=parseInt(document.getElementById("assign").value);
		if(mpt_marks<0 || mtt_marks <0 || assign_marks <0)
		{
			alert("marks can not be less than 0");
			return false;
		}
		else
		{
			total_marks=parseInt(mpt_marks+mtt_marks+assign_marks);
			if(total_marks<=100 && total_marks >=90)
			{
				score=5;
				st='PASS';
				return true;
			}
			else if(total_marks<=89 && total_marks >=80)
			{
				score=4;
				st='PASS';
				return true;
			}
			else if(total_marks<=79 && total_marks >=70)
			{
				score=3;
				st='PASS';
				return true;
			}
			else if(total_marks<=69 && total_marks >=60)
			{
				score=2;
				st='PASS';
				return true;
			}
			else if(total_marks<=59 && total_marks>=50)
			{
				score=1;
				st='FAIL';
				return true;
			}
			else
			{
				score=0;
				st='FAIL';
				return true;
				
			}
		
		}
	}
		function category()
{
	var catdata=window.document.form1.domain.value;
	
	if(catdata=="JEE")
	{
		window.document.form1.catval.options[0].text="Core Java";
		window.document.form1.catval.options[0].value="Core Java";
		
		window.document.form1.catval.options[1].text="Servlet";
		window.document.form1.catval.options[1].value="Servlet";
		
		window.document.form1.catval.options[2].text="Spring";
		window.document.form1.catval.options[2].value="Spring";

		
	}
	
	if(catdata==".NET")
	{
		window.document.form1.catval.options[0].text="C#";
		window.document.form1.catval.options[0].value="C#";
		
		window.document.form1.catval.options[1].text="ADO.NET";
		window.document.form1.catval.options[1].value="ADO.NET";
		
		window.document.form1.catval.options[2].text="ASP.NET";
		window.document.form1.catval.options[2].value="ASP.NET";
		
	}
	
}

function validate()
	{
	if(isNumber())
		{
		if(isName())
			{
			 if(total())
			 {
				 return true;
			 }
			}
		}
		return false;
	}
		function display()
		{
				if(validate())
				{
					alert("Trainee Number"+"  "+num+"\n"+"Trainee Name"+"  "+name+"\n"+"Total marks is"+"  "+total_marks+"\n"+"Score is"+"  "+score+"\n"+"Status is"+"  "+st);
					
						
						alert("DATA SUBMITTED SUCCESSFULLY");
					
					
				}
				else
				{
					alert("DATA NOT SUBMITTED");
				}
		}