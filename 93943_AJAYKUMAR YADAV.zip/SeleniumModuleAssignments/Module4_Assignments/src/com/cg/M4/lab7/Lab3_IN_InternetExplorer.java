package com.cg.M4.lab7;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab3_IN_InternetExplorer {
	
	static String driverpath = "D:\\AJAYKUMAR 093943_IN\\VNV Software\\Selenium\\WebDrivers\\WebDriver_Java\\driver\\";
	static WebDriver driver;
	
	public static void main(String args[]) throws InterruptedException{
	
//		Launch Application
		System.setProperty("webdriver.ie.driver", driverpath+"IEDriverServer.exe");
		driver=new InternetExplorerDriver();
		driver.manage().window().maximize();
 
//		1. Launch the URL on Chrome
		driver.navigate().to("http://demo.opencart.com/");
		Thread.sleep(2000);
		
//		  2. Verify 'Title' of the page
		  if(driver.getTitle().contains("Your Store"))
		  {
		      System.out.println("Title Test Case Passed");	  
		  }
		  else
		  {
			  System.out.println("Title Test Case Failed");
		  }

//		  3. Click on 'My Account' dropdown
		  driver.findElement(By.xpath("//i[@class='fa fa-user']")).click();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
//		  4. Select 'Register' from dropdown		  
//		  WebElement wb1 = driver.findElement(By.xpath("//i[@class='fa fa-user']"));
//		  Select sel = new Select(wb1);
		  driver.findElement(By.linkText("Register")).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
//		  5. �Register Account� page will open up, verify the heading �Register Account�

		  WebElement wb1 = driver.findElement(By.xpath("//div[@id='content']/h1"));
		  
		  System.out.println(wb1.getText());
		  
		  if(wb1.getText().contains("Register Account"))
		  {
		      System.out.println("table title Case Passed");	  
		  }
		  else
		  {
			  System.out.println("table title Failed");
		  }
		  
//		  6. Click on 'Continue' button at the bottom of the page
		  driver.findElement(By.xpath("//input[@value='Continue']")).click();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

//		  7. Verify warning message 'Warning: You must agree to the Privacy Policy!'
 		  WebElement wb2 = driver.findElement(By.xpath("//*[@id='account-register']/div[1]"));
    	  boolean txt = driver.getPageSource().contains("Warning: You must agree to the Privacy Policy!");
		  if(txt)
		  {
		      if(wb2.getText().contains("Warning: You must agree to the Privacy Policy!"))
		      {
		          System.out.println("Warning message Passed");	  
		      }
		      else
		      {
		    	  System.out.println("Warning message Failed");
	    	  }
		  }


//    	1. Enter data in 'First Name' text box
		driver.findElement(By.name("firstname")).sendKeys("abcdeghijklmnopqrstuvwxyzqqqqqqqqqqqqqqqqqq");
	    String firstName = driver.findElement(By.name("firstname")).getAttribute("value");
	    System.out.println("Length of first name :"+firstName.length());
    
//    	2. Verify if 33 characters can be entered in 'First Name' text box by clicking
//    	on 'Continue' button.
//    	3. If not, verify error message.

	    String firstNameError = "First Name must be between 1 and 32 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
			if(wbt3.getText().equals(firstNameError)){
				System.out.println("First Name Error message is verified");
			}
			else{
				System.out.println("First Name Error message is verified");
			}
			//give positive first name
			driver.findElement(By.name("firstname")).clear();
			driver.findElement(By.name("firstname")).sendKeys("abcde");
		}catch(Exception exp1){
			System.out.println("First Name is in correct format");
        }


//    	2. Enter data in 'last Name' text box
		driver.findElement(By.name("lastname")).sendKeys("abcdeghijklmnopqrstuvwxyzqqqqqqqqqqqqqqqqqq");
	    String lastName = driver.findElement(By.name("lastname")).getAttribute("value");
	    System.out.println("Length of last name :"+lastName.length());
    
//    	2. Verify if 33 characters can be entered in 'last Name' text box by clicking
//    	on 'Continue' button.
//    	3. If not, verify error message.

	    String lastNameError = "Last Name must be between 1 and 32 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
			if(lastNameError.equals(wbt3.getText())){
				System.out.println("last Name Error message is verified");	
			}
			else{
				System.out.println("last Name Error message is not verified");	
			}
			
			//give positive last name
			driver.findElement(By.name("lastname")).clear();
			driver.findElement(By.name("lastname")).sendKeys("abcde");
		}catch(Exception exp2){
			System.out.println("Last Name is in correct format");
        }
       
        //Email and telephone
        String email;
        String emailError="E-Mail Address does not appear to be valid!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
        	driver.findElement(By.id("input-email")).sendKeys("ajay@gmail.com");
        	email=driver.findElement(By.id("input-email")).getAttribute("value");
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[4]/div/div"));
			if(emailError.equals(wbt3.getText())){
				System.out.println("Email Error message is verified");	
			}
			else{
				System.out.println("Email Error message is not verified");
			}
		}catch(Exception exp3){
			System.out.println("Email is in correct format");
        }
        
        String tel;
        String telephoneError="Telephone must be between 3 and 32 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
        	driver.findElement(By.id("input-telephone")).sendKeys("04226541441");
        	tel=driver.findElement(By.id("input-telephone")).getAttribute("value");
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[5]/div/div"));
			if(telephoneError.equals(wbt3.getText())){
			System.out.println("Telephone Error message is verified");
			}
			else{
				System.out.println("Telephone Error message is not verified");
			}
			//give positive telephone
			driver.findElement(By.id("input-telephone")).clear();		
			driver.findElement(By.id("input-telephone")).sendKeys("04226541441");
		}catch(Exception exp4){
			System.out.println("Telephone is in correct format");
        }
        
        //Password
        String password = null;
        String passwordError="Password must be between 4 and 20 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
        	driver.findElement(By.name("password")).sendKeys("Yadav");
        	password=driver.findElement(By.name("password")).getAttribute("value");
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset[2]/div[1]/div/div"));
			if(passwordError.equals(wbt3.getText())){
				System.out.println("Password Error message is verified");	
			}
			else{
				System.out.println("Password Error message is not verified");	
			}
		}catch(Exception exp5){
			System.out.println("Password is in correct format");
        }
        
        //Confirm Password
        String confirmPassword;
        String confirmPasswordError="Password confirmation does not match password!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
        	driver.findElement(By.id("input-confirm")).sendKeys("Yadav");
        	confirmPassword=driver.findElement(By.id("input-confirm")).getAttribute("value");
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset[2]/div[2]/div/div"));
			if(confirmPasswordError.equals(wbt3.getText())){
			System.out.println("Confirm Password Error message is verified");
			}
			else{
				System.out.println("Confirm Password Error message is not verified");
			}
		}catch(Exception exp6){
			System.out.println("Confirm Password is in correct format");
        }
        
        //Radio Button
        driver.findElement(By.name("newsletter")).click();
        
        //Privacy policy
        driver.findElement(By.name("agree")).click();
        
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //Account message Verification 
        WebElement wb4 = driver.findElement(By.xpath("//*[@id='content']/h1"));
        String Accmessage = wb4.getText();
        String Vermessage ="Your Account Has Been Created!";
        
        if(Vermessage.equals(Accmessage)) {
        System.out.println("Account creation message is verified");
        }
        else{
            System.out.println("Account creation message is not verified");
        }
        	
        
        //clicking Continue
        driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 
        //Address
        driver.findElement(By.xpath("//*[@id='column-right']/div/a[4]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //FirstName add       
        driver.findElement(By.id("input-firstname")).sendKeys("Yadav");
        
        //LastName add
        driver.findElement(By.id("input-lastname")).sendKeys("Yadav");
        
        //CompanyName   add
        driver.findElement(By.id("input-company")).sendKeys("Capgemini");
        
        //Address
        driver.findElement(By.id("input-address-1")).sendKeys("Coimbatore");
	    String address = driver.findElement(By.id("input-address-1")).getAttribute("value");
	    System.out.println("Length of Address:"+address.length());
    
	    String addressError = "Address must be between 3 and 128 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[4]/div/div"));
			if(addressError.equals(wbt3.getText())){
				System.out.println("address Error message is verified");	
			}
			else{
				System.out.println("address Error message is not verified");	
			}
			//give positive address
			driver.findElement(By.id("input-address-1")).clear();
			driver.findElement(By.id("input-address-1")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("address is in correct format");
        }

        
        //City add
        driver.findElement(By.id("input-city")).sendKeys("Bangalore");
	    String city = driver.findElement(By.id("input-city")).getAttribute("value");
	    System.out.println("Length of city:"+city.length());
    
	    String cityError = "City must be between 3 and 128 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[6]/div/div"));
			if(cityError.equals(wbt3.getText())){
			System.out.println("City Error message is verified");
			}
			else{
				System.out.println("City Error message is verified");
			}
			//give positive city
			driver.findElement(By.id("input-city")).clear();
			driver.findElement(By.id("input-city")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("city is in correct format");
        }

        //Post code add
        driver.findElement(By.id("input-postcode")).sendKeys("641006");
	    String postCode = driver.findElement(By.id("input-postcode")).getAttribute("value");
	    System.out.println("Length of Post Code:"+postCode.length());
    
	    String postCodeError = "Postcode must be between 2 and 10 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
 			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[7]/div/div"));
			if(postCodeError.equals(wbt3.getText())){
			System.out.println("Post Code Error message is verified");
			}
			else{
				System.out.println("Post Code Error message is not verified");
			}
			//give positive Post Code
			driver.findElement(By.id("input-postcode")).clear();
			driver.findElement(By.id("input-postcode")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("Post Code is in correct format");
        }
        
        //Country name
        WebElement wb11 = driver.findElement(By.id("input-country"));
        Select sel = new Select(wb11);
        sel.selectByValue("222");
        Thread.sleep(3000);
        //Region and Zone
        WebElement wb22 = driver.findElement(By.id("input-zone"));
        Select sel1 = new Select(wb22);
        sel1.selectByValue("3525");
        
        driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
        //Close Application
        driver.close();
}
}