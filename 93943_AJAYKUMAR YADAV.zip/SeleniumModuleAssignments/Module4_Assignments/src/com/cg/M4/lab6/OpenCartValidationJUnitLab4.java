package com.cg.M4.lab6;

import static org.junit.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class OpenCartValidationJUnitLab4
{

	static String driverpath = "D:\\AJAYKUMAR 093943_IN\\VNV Software\\Selenium\\WebDrivers\\WebDriver_Java\\driver\\";

	static WebDriver driver;

	@BeforeClass
	public static void init(){
//		Launch Application
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@AfterClass
	public static void destroy(){

//		Close Application
		driver.close();
		}

	@Test
	public void testLab4() throws InterruptedException{
//		1. Launch the URL on Chrome
		driver.get("https://demo.opencart.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println(driver.getCurrentUrl());
		assertEquals("https://demo.opencart.com/",driver.getCurrentUrl());

		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Select Login 
	    driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	    //Enter Email
	    driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys("ajayadav@gmail.com");

	    //Enter Password
	    driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("Yadav");
		
	    //Login
	    driver.findElement(By.xpath("//*[@id='content']/div/div[2]/div/form/input[1]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	    //Select Component
	    driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a")).click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
		//Select Monitor
	    driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
		//Select Show
	     WebElement wb1 = driver.findElement(By.id("input-limit"));
	     Select sel = new Select(wb1);
	     sel.selectByVisibleText("25");

//	     	     assertEquals("25", wb1.getAttribute("value"));

	    //Add to cart
	     driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
	     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


         driver.findElement(By.linkText("Specification")).click();
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	         
	 		//12.Verify details present on the page.
	 		String getheading = driver.findElement(By.xpath("//*[@id='tab-specification']/table/thead/tr/td/strong")).getText();
	 		assertEquals("Processor", getheading);
//	 		if(getheading.equals("Processor"))
//	 		{
//	 			System.out.println("Description table Heading Verified");	
//	 		}
//	 		else
//	 		{
//	 			System.out.println("Description table Heading not Verified");
//	 		}

	 		
	 		String getlabel = driver.findElement(By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[1]")).getText();
	 		assertEquals("Clockspeed", getlabel);
//	 		if(getlabel.equals("Clockspeed"))
//	 		{
//	 			System.out.println("table label Verified");	
//	 		}
//	 		else
//	 		{
//	 			System.out.println("table label not Verified");
//	 		}
	 		
	 		String getdata = driver.findElement(By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[2]")).getText();
	 		assertEquals("100mhz", getdata);
//	 		if(getdata.equals("100mhz"))
//	 		{
//	 			System.out.println("table data Verified");	
//	 		}
//	 		else
//	 		{
//	 			System.out.println("table data not Verified");
//	 		}
	 		
	 		//13.Click on 'Add to Wish list' button.
	 		driver.findElement(By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
	 		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 		
	 		//14.Verify message 'Success: You have added Apple Cinema 30" to your wish list!'
    	     String msg=driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText();
//		     System.out.println(msg);
		     if(msg.equals("Success: You have added Apple Cinema 30\" to your wish list!\n�"))
		    	 System.out.println("Success verified");
		     else
		    	 System.out.println("Success not verified");

	 		
			//15.Enter 'Mobile' in ' Search' text box.
			driver.findElement(By.name("search")).sendKeys("Mobile");
			
			//16.Click on 'Search' button.
			driver.findElement(By.name("search")).sendKeys(Keys.ENTER);
			
			//17.Click on 'Search in product descriptions' check box.
			driver.findElement(By.name("description")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//18.Click on 'Search' button.
			driver.findElement(By.id("button-search")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//19.Click on link 'HTC Touch HD' for the mobile 'HTC Touch HD'.
			driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[1]/a/img")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//20.Clear '1' from 'Qty' and enter '3'.
			driver.findElement(By.id("input-quantity")).clear();
			driver.findElement(By.id("input-quantity")).sendKeys("3");
			
			//21.Click on 'Add to Cart' button.
			driver.findElement(By.id("button-cart")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//22.Verify success message 'Success: You have added HTC Touch HD to your shopping cart!'
			String successmsg1 = driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText();
			System.out.println("Verifying success msg:"+successmsg1.equals("You must login or create an account to save HTC Touch HD to your wish list!"));
			
			//23.Click on 'View cart' button adjacent to search button.
			driver.findElement(By.xpath("//*[@id='cart']/button")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//24.Verify Mobile name added to the cart.
			String mobilename = driver.findElement(By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a")).getText();
			System.out.println("Verifying Mobile Name: "+mobilename.equals("HTC Touch HD"));

			//25.Click on 'Checkout' button.
//			driver.findElement(By.xpath("//*[@id='cart']/ul/li[2]/div/p/a[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"cart\"]/ul/li[2]/div/p/a[1]/strong/i")).click();

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//26.Click on 'Checkout' button.
//			driver.findElement(By.xpath("//*[@id='content']/div[3]/div[2]/a")).click();
			driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[5]/a/span")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			//27.Click on 'My Account' dropdown.
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//28.Select 'Logout' from dropdown.
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//29.Verify 'Account Logout' heading.
			String heading = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
			assertEquals(heading, "Account Logout");
			System.out.println("Account Logout heading verified");

			
			//30.Click on 'Continue'.
			driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
}
