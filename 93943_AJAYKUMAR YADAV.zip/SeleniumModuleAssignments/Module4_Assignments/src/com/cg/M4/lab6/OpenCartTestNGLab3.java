package com.cg.M4.lab6;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class OpenCartTestNGLab3 {
	
	static String driverpath = "D:\\AJAYKUMAR 093943_IN\\VNV Software\\Selenium\\WebDrivers\\WebDriver_Java\\driver\\";
	static WebDriver driver;
	
	@BeforeClass
	public static void init(){
//		Launch Application
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@AfterClass
	public static void destroy(){
//		Close Application
		driver.close();
		}
		
	@Test(priority=0)
	public void testURL(){
//		1. Launch the URL on Chrome
		driver.navigate().to("https://demo.opencart.com/index.php?route=account/register");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println(driver.getCurrentUrl());
		Assert.assertEquals("https://demo.opencart.com/index.php?route=account/register",driver.getCurrentUrl());
	}
	
	@Test(priority=1)
	public void testFirstName(){
//    	1. Enter data in 'First Name' text box
		driver.findElement(By.name("firstname")).sendKeys("abcdeghijklmnopqrstuvwxyzqqqqqqqqqqqqqqqqqq");
	    String firstName = driver.findElement(By.name("firstname")).getAttribute("value");
	    System.out.println("Length of first name :"+firstName.length());
    
//    	2. Verify if 33 characters can be entered in 'First Name' text box by clicking
//    	on 'Continue' button.
//    	3. If not, verify error message.


	    String firstNameError = "First Name must be between 1 and 32 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
        	WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
        	Assert.assertEquals(firstNameError,wbt3.getText());
			System.out.println("First Name Error message is verified");
			//give positive first name
			driver.findElement(By.name("firstname")).clear();
			driver.findElement(By.name("firstname")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("First Name is in correct format");
        }
	}
	
	@Test(priority=2)
	public void testLastName(){
//    	2. Enter data in 'last Name' text box
		driver.findElement(By.name("lastname")).sendKeys("abcdeghijklmnopqrstuvwxyzqqqqqqqqqqqqqqqqqq");
	    String lastName = driver.findElement(By.name("lastname")).getAttribute("value");
	    System.out.println("Length of last name :"+lastName.length());
    
//    	2. Verify if 33 characters can be entered in 'last Name' text box by clicking
//    	on 'Continue' button.
//    	3. If not, verify error message.

	    String lastNameError = "Last Name must be between 1 and 32 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
			Assert.assertEquals(lastNameError,wbt3.getText());
			System.out.println("last Name Error message is verified");
			//give positive last name
			driver.findElement(By.name("lastname")).clear();
			driver.findElement(By.name("lastname")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("Last Name is in correct format");
        }
	}
     
	@Test(priority=3)
	public void testEmail(){
	//Email and telephone
        String email;
        String emailError="E-Mail Address does not appear to be valid!";
        
        try{
        	driver.findElement(By.id("input-email")).sendKeys("ajaykumar@gmail.com");
        	email=driver.findElement(By.id("input-email")).getAttribute("value");
        	driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[4]/div/div"));
			Assert.assertEquals(emailError,wbt3.getText());
			System.out.println("Email Error message is verified");
		}catch(Exception exp){
			System.out.println("Email is in correct format");
        }
	}
	
	@Test(priority=4)
	public void testTelephone(){
        String tel;
        String telephoneError="Telephone must be between 3 and 32 characters!";
        
        try{
        	driver.findElement(By.id("input-telephone")).sendKeys("04226541441");
        	tel=driver.findElement(By.id("input-telephone")).getAttribute("value");
            driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[5]/div/div"));
			Assert.assertEquals(telephoneError,wbt3.getText());
			System.out.println("Telephone Error message is verified");
		}catch(Exception exp){
			System.out.println("Telephone is in correct format");
        }
	}
     
	@Test(priority=5)
	public void testPassword(){
        //Password
        String password = null;
        String passwordError="Password must be between 4 and 20 characters!";

        try{
        	driver.findElement(By.name("password")).sendKeys("Yadav");
        	password=driver.findElement(By.name("password")).getAttribute("value");
            driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset[2]/div[1]/div/div"));
			Assert.assertEquals(passwordError,wbt3.getText());
			System.out.println("Password Error message is verified");
		}catch(Exception exp){
			System.out.println("Password is in correct format");
        }
	}
	
	@Test(priority=6)
	public void testConfirmPassword(){
        //Confirm Password
        String confirmPassword;
        String confirmPasswordError="Password confirmation does not match password!";
        
        try{
        	driver.findElement(By.id("input-confirm")).sendKeys("Yadav");
        	confirmPassword=driver.findElement(By.id("input-confirm")).getAttribute("value");
            driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset[2]/div[2]/div/div"));
            Assert.assertEquals(confirmPasswordError,wbt3.getText());
			System.out.println("Confirm Password Error message is verified");
		}catch(Exception exp){
			System.out.println("Confirm Password is in correct format");
        }
	}
	
	@Test(priority=7)
	public void teststeps(){
        //Radio Button
        driver.findElement(By.name("newsletter")).click();
        
        //Privacy policy
        driver.findElement(By.name("agree")).click();
        
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //Account message Verification 
        WebElement wb4 = driver.findElement(By.xpath("//*[@id='content']/h1"));
        String Accmessage = wb4.getText();
        String Vermessage ="Your Account Has Been Created!";
        
        Assert.assertEquals(Vermessage,Accmessage);
        
        //clicking Continue
        driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 
        //Address
        driver.findElement(By.xpath("//*[@id='column-right']/div/a[4]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //FirstName add       

        driver.findElement(By.id("input-firstname")).sendKeys("Yadav");
        //LastName add
        driver.findElement(By.id("input-lastname")).sendKeys("Yadav");
        
        //CompanyName   add
        driver.findElement(By.id("input-company")).sendKeys("Capgemini");

	}
	
	@Test(priority=8)
	public void testAddress1(){
        //Address

        driver.findElement(By.id("input-address-1")).sendKeys("Coimbatore");
	    String address = driver.findElement(By.id("input-address-1")).getAttribute("value");
	    System.out.println("Length of Address:"+address.length());
    

	    String addressError = "Address must be between 3 and 128 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[4]/div/div"));
			Assert.assertEquals(addressError,wbt3.getText());
			System.out.println("address Error message is verified");
			//give positive address
			driver.findElement(By.id("input-address-1")).clear();
			driver.findElement(By.id("input-address-1")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("address is in correct format");
        }
	}

     
	@Test(priority=9)
	public void testCity(){
        //City add
        driver.findElement(By.id("input-city")).sendKeys("Bangalore");
	    String city = driver.findElement(By.id("input-city")).getAttribute("value");
	    System.out.println("Length of city:"+city.length());
    
	    String cityError = "City must be between 3 and 128 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[6]/div/div"));
			Assert.assertEquals(cityError,wbt3.getText());
			System.out.println("City Error message is verified");
			//give positive city
			driver.findElement(By.id("input-city")).clear();
			driver.findElement(By.id("input-city")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("city is in correct format");
        }
	}
	
	@Test(priority=10)
	public void testPostCode(){
        //Post code add
        driver.findElement(By.id("input-postcode")).sendKeys("641006");
	    String postCode = driver.findElement(By.id("input-postcode")).getAttribute("value");
	    System.out.println("Length of Post Code:"+postCode.length());
	    String postCodeError = "Postcode must be between 2 and 10 characters!";
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        try{
			WebElement wbt3 = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[7]/div/div"));
			System.out.println("Post Code Error message is verified");
			//give positive Post Code
			driver.findElement(By.id("input-postcode")).clear();
			driver.findElement(By.id("input-postcode")).sendKeys("abcde");
		}catch(Exception exp){
			System.out.println("Post Code is in correct format");
        }
	}
     
	@Test(priority=11)
	public void testSteps() throws InterruptedException{
        //Country name
        WebElement wb11 = driver.findElement(By.id("input-country"));
        Select sel = new Select(wb11);
        sel.selectByValue("222");
        Thread.sleep(3000);
        //Region and Zone
        WebElement wb22 = driver.findElement(By.id("input-zone"));
        Select sel1 = new Select(wb22);
        sel1.selectByValue("3525");
        
        driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
}

		


