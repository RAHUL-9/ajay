/*5.2.1: Consider the Person class created in lab assignment 1.6.
 *  This class has some members and corresponding setter and getter methods.
 *  Write test case to check the functionality of getter methods and displaydetails method.
 */
package com.cg.lab5;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestPerson1 {

	static Person per;


	@Test
	public void testGetFirstName(){
	
		assertEquals("jabbar",per.getFirstName());
	}

	
	@Test
	public void testGetLastName(){
	
		assertTrue(per.getLastName()=="abdul");
	}


	@Test
	public void testGetMobileNum(){
	
		assertTrue(per.getMobileNum()=="9876543210");
	}
	
	@Test
	public void testGetGender(){
	
		assertTrue(per.getGender()=='m');
	}
	
	@BeforeClass
	public static void init()
	{
		per = new Person("jabbar","abdul",'m',"9876543210");
	}

	@AfterClass
	public static void destroy()
	{
		per = null;
	}
}
