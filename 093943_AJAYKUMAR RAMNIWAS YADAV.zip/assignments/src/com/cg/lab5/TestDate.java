package com.cg.lab5;

import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestDate {

	static Date date;
	
	@Test
	public void testSetDay(){
	
		date.setDay(11);
		assertTrue(date.getDay()==11);
	}

	@Test
	public void testGetDay(){
		
		date.setDay(15);
		assertTrue(date.getDay()==15);
	}
	
	@Test
	public void testSetMonth(){
	
		date.setMonth(9);
		assertTrue(date.getMonth()==9);
	}
	
	@Test
	public void testGetMonth(){
	
		date.setMonth(10);
		assertTrue(date.getMonth()==10);
	}	
	
	@Test
	public void testSetYear(){
	
		date.setYear(1998);
		assertTrue(date.getYear()==1998);
	}

	@Test
	public void testGetYear(){
	
		date.setYear(2017);
		assertTrue(date.getYear()==2017);
	}
	
	@BeforeClass
	public static void init()
	{
		date = new Date(05,11,1996);
	}

	@AfterClass
	public static void destroy()
	{
		date = null;
	}

	
}
