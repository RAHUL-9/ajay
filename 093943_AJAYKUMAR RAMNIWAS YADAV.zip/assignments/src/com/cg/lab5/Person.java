package com.cg.lab5;

public class Person {

       private String firstName;
       private String lastName;
       private char gender;
       private String mobileNum;
       
       
       public Person(){
              firstName = "Jabbar";
              lastName = "Mohd";
              gender = 'M';
              mobileNum = "9123456789";
       }

       public Person(String fname , String lname , char gen, String mnum){
              firstName = fname;
              lastName = lname;
              gender = gen;
              mobileNum = mnum;
       }

       public String getFirstName() {
              return firstName;
       }

       public void setFirstName(String firstName) {
              this.firstName = firstName;
       }

       public String getLastName() {
              return lastName;
       }

       public String getMobileNum() {
              return mobileNum;
       }

       public void setMobileNum(String mobileNum) {
              this.mobileNum = mobileNum;
       }

       public void setLastName(String lastName) {
              this.lastName = lastName;
       }

       public char getGender() {
              return gender;
       }

       public void setGender(char gender) {
              this.gender = gender;
       }
       
       public void disp(){
                 System.out.println("Person Details");
                 System.out.println("_______________");
                 System.out.println("First Name:"+firstName);
                 System.out.println("Second Name:"+lastName);
                 System.out.println("Gender:"+gender);
                 System.out.println("Mobile Number:"+mobileNum);
       }
       
       public static void main(String[] args) {


                 Person per = new Person("ajay","yadav",'m',"9876543210");

                 per.disp();

                 
       }
       
}
