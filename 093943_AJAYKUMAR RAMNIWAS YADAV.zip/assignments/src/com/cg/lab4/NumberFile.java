package com.cg.lab4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Pattern;

public class NumberFile {
	static Pattern pat=Pattern.compile(",");
	
	public static void main(String[] args) throws IOException
	{
		StringBuilder sb=null;

			File f=new File("D:\\Training\\Spring4Practice\\assignments\\src\\com\\cg\\lab4\\number.txt");
			FileReader r=new FileReader(f);
			BufferedReader br=new BufferedReader(r);
			String rev;
			while((rev=br.readLine())!=null)
			{
				System.out.println(sb);
				for(String val:pat.split(rev))
				{
					if(Integer.parseInt(val)%2 == 0 ){
					System.out.println(val);
					}
				}
			}


			r.close();

}
}
