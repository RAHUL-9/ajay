package com.cg.lab4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class FileRaderWriter {
	static String reverse;
	

	public static void main(String[] args) throws IOException
	{
		StringBuilder sb=null;

			File f=new File("D:\\Training\\Spring4Practice\\assignments\\src\\com\\cg\\lab4\\read.txt");
			FileReader r=new FileReader(f);
			BufferedReader br=new BufferedReader(r);
			String rev;
			while((rev=br.readLine())!=null)
			{
				System.out.println(rev);
				sb=new StringBuilder(rev);  
			    sb.reverse();  
			    System.out.println(sb);
			}
			
			r.close();
			
			br.close();
			File f1=new File("D:\\Training\\Spring4Practice\\assignments\\src\\com\\cg\\lab4\\read.txt");
			FileWriter w=new FileWriter(f1);
			w.write(sb.toString());
			w.flush();
			w.close();
			
			
			
			
			
			
	


	}

}
