package com.cg.lab1;

public class PersonMain 
{
	private String FirstName;
	private String LastName;
	private char Gender;
	
	public PersonMain()
	{
		
	}

	public PersonMain(String firstName, String lastName, char gender) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public char getGender() {
		return Gender;
	}

	public void setGender(char gender) {
		Gender = gender;
	}

	public static void main(String[] args) {
		
		PersonMain p=new PersonMain("Ajaykumar","Yadav",'M');
		System.out.println("Person Details");
		System.out.println("______________");
		System.out.println("");
		System.out.println("First Name : "+p.FirstName);
		System.out.println("Last Name : "+p.LastName);
		System.out.println("Gender : "+p.Gender);
		
		
		

	}

}
