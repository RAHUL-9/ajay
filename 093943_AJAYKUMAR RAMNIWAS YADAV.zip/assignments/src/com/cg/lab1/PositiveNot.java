package com.cg.lab1;

import java.util.Scanner;

public class PositiveNot 
{
	

	private static Scanner sc;

	public static void main(String[] args) 
	{
		
		sc = new Scanner(System.in);
		System.out.println("Enter any integer value");
		int num=sc.nextInt();
		if(num>0)
		{
			System.out.println("Entered integer is positive integer");
		}
		else
		{
			System.out.println("Entered integer is negative integer");
		}
	

	}

}
