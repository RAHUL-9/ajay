package com.cg.lab1;

import java.util.Scanner;

public class PositiveString {

	private static Scanner sc;

	public static void main(String[] args)
	{
		sc = new Scanner(System.in);
		int dummy=0;
		System.out.println("Enter the any String");
		String word=sc.next();
		System.out.println("");
		for(int i=0;i<word.length()-1;i++)
		{
			if(word.charAt(i) > word.charAt(i+1))
			{
				System.out.println("It is not a positive String");
				dummy = -1;
				break;
			}
			
		}
		
		if (dummy!=-1)
		{
			System.out.println("It is a positive String");
		}

	}

}
