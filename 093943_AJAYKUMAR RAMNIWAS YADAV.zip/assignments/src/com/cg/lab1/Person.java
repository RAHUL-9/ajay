package com.cg.lab1;

public class Person 
{
	@Override
	public String toString() {
		return "Person [FirstName=" + FirstName + ", LastName=" + LastName
				+ ", Gender=" + Gender + "]";
	}

	private String FirstName;
	private String LastName;
	private char Gender;
	
	Person()
	{
					
	}

	public Person(String firstName, String lastName, char gender)
	{
		
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public char getGender() {
		return Gender;
	}

	public void setGender(char gender) {
		Gender = gender;
	}

	public static void main(String[] args) {
		
		Person p=new Person();
		p.setFirstName("Ajaykumar");
		p.setLastName("Yadav");
		p.setGender('M');
		System.out.println("Person Details");
		System.out.println("______________");
		System.out.println("");
		System.out.println("First Name : "+p.getFirstName());
		System.out.println("Last Name : "+p.getLastName());
		System.out.println("Gender : "+p.getGender());
		
		
		

	}

}
