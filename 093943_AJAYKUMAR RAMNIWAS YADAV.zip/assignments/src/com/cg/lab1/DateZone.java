package com.cg.lab1;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class DateZone {

	private static Scanner sc;

	public static void main(String[] args) 
	{
		System.out.println("Enter the zone id :");
		sc = new Scanner(System.in);
		String input=sc.next();
		ZonedDateTime zoneid = ZonedDateTime.now(ZoneId.of(input));
		System.out.println("zone time"+zoneid);

	}

}
