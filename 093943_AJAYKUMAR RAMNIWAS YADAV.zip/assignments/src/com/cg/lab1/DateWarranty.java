package com.cg.lab1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateWarranty {

	public static void main(String[] args)
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter date in mm/yyyy format:");
		String date  = sc.nextLine();
		LocalDate purchasedate = LocalDate.parse(date,formatter);
		System.out.println(purchasedate);
		//int month=sc.nextInt();
		//int  year=sc.nextInt();
		//String a =  date.plusYears(year).toString();

	}

}
