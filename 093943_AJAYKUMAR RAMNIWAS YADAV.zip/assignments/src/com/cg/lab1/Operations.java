package com.cg.lab1;

import java.util.Scanner;

public class Operations 
{
	public static String word;
	String output="";
	public void addString()
	{
		System.out.println("Enter the string to add");
		String add=sc.next();
		add=word.concat(add);
		System.out.println(add);
	}
	public void replaceOdd()
	{
		 for (int i=0; i < word.length(); i++)
		 {
		        if (i % 2 != 0){
		          word = word.substring(0,i-1) + "#" + word.substring(i, word.length());
		        }
		 }
		 System.out.println(word);
	}
	public void removeDuplicate()
	{
		 for(int i=0; i<word.length(); i++)
	        {
	          char  ch = word.charAt(i);
	            if(ch!=' ')
	              output = output + ch;
	            word = word.replace(ch,' ');
	        }
	 
	       System.out.println("String after removing duplicate characters : " + output);
		
	}
	public void uppercase()
	{

        String newword = "";

        String temp = "";

        for (int i = 0; i < word.length(); i++)
        {

            if (i % 2 == 0)
            {

                temp = "";

                temp += word.charAt(i);

                temp = temp.toUpperCase();

                newword += temp;

            } 
            else 
            {

                temp = "";

                temp += word.charAt(i);

                temp = temp.toLowerCase();

                newword += temp;

            }
        }
        System.out.println("Odd charcters in UPPERCASE :"+newword);


	}

	private static Scanner sc;

	public static void main(String[] args)
	{
		Operations o=new Operations();
		sc = new Scanner(System.in);
		System.out.println("Enter the any String");
		word=sc.next();
		System.out.println("");
		System.out.println("Operations user can performed");
		System.out.println("1.Add String to itself");
		System.out.println("2.Replace the odd position with #");
		System.out.println("3.Remove duplicates characters in the string");
		System.out.println("4.Change odd characters to uppercase");
		
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		
		if(choice==1)
		{
			o.addString();
		}
		else if(choice==2)
		{
			o.replaceOdd();
		}
		else if(choice==3)
		{
			o.removeDuplicate();
		}
		else if(choice==4)
		{
			o.uppercase();
		}
		else
		{
			System.out.println("Enter the correct operation options");
		}

	}

}
