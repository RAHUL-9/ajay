package com.cg.lab1;

public class PhoneNumber 
{
	private String FirstName;
	private String LastName;
	private char Gender;
	private String Number;
	
	

	public void setInfo(String firstName, String lastName, char gender,String number) 
	{

		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		Number = number;
	}
	public void display()
	{
		System.out.println("Person Details");
		System.out.println("______________");
		System.out.println("");
		System.out.println("First Name : "+FirstName);
		System.out.println("Last Name : "+LastName);
		System.out.println("Gender : "+Gender);
		System.out.println("Phone Number : "+Number);
	}



	public static void main(String[] args)
	{
		
		PhoneNumber pn=new PhoneNumber();
		pn.setInfo("Ajaykumar","Yadav",'M',"7666615638");
		pn.display();
		
	}

}
