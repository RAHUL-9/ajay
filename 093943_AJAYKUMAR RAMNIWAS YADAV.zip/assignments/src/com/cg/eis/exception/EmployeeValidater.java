
package com.cg.eis.exception;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class EmployeeValidater {
	
	// implement each validateMethod
	public boolean isEmployeeSalaryValid(String empSalary)throws EmployeeException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[0-9]{2,5}[.][0-9]{0,2}$");
		
		Matcher mat= pat.matcher(empSalary);
		
		if(!mat.find()){
			
			throw new EmployeeException("Sorry Your Salary is not in double format");
			
		}
		
        if(Double.parseDouble(empSalary)<3000){
			
			throw new EmployeeException("Sorry Your salary must be > 3000.00");
			
		}
		
		
		return flag;

	}
	

}
