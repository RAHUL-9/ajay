package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.service.EmployeeServiceImp;



public class EmployeeDetails {
	
	Scanner scan = new Scanner(System.in);
	
	
	
	static EmployeeDetails emp = new EmployeeDetails();
	
	public static void main(String[] args) {
		
		
		emp.menu();
		
		
		

	}
	
	public void menu()
	{
		int ch = 0;
		System.out.println("1.To add new Employee Details");
		System.out.println("2.Find the employee with Insurance Scheme Name");
		System.out.println("3.To View all records");
		System.out.println("4.Exit");
		System.out.println("Enter your choice : ");
        ch=scan.nextInt();
		switch (ch)
		{
		case 1:
			new EmployeeServiceImp().addEmployee();
			break;
		case 2:
			
			new EmployeeServiceImp().findInsuranceScheme();
			break;
			
		case 3:
			new EmployeeServiceImp().getAllEmployee();
			break;
			
		case 4:
			System.out.println("-----Exit-----");
			break;
			
		default:
			System.err.println("Please enter the correct choice");
		}
		System.out.println("---------------------------------");
		if(ch !=4 )
		{
		menu();
		}
	}




}
