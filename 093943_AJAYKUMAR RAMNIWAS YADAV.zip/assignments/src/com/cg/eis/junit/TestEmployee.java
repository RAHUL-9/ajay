package com.cg.eis.junit;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.StaticPrg;

public class TestEmployee {

	static StaticPrg empstatic;
	static Employee empobj;

		
	@Test (expected=IllegalArgumentException.class)
	public void testEmployee() 
		{

			Employee emp1 = new Employee(123, null, 1234, null, null);
		}
	
	
	@Test
	public void testCountTotEmployee() 
	{
		assertTrue(empstatic.countTotEmployee()>=2);
		
	}

	@Test
	public void testAddEmployee()
	{
		
		empobj.setName("AJAY");
		empobj.setId(123);
		empobj.setSalary(3001.00);
		empobj.setDesignation("Manager");
		empobj.setInsuranceScheme("Medical Insurance");
		empstatic.addEmployee(empobj);
		int len=empstatic.countTotEmployee();
		assertTrue(empstatic.countTotEmployee()==len);
		
	}

	@BeforeClass
	public static void init()
	{
		empstatic=new StaticPrg();
		empobj=new Employee();
		
	}
	
	@AfterClass
	public static void destroy()
	{
		empstatic=null;
		empobj=null;
	}
	
	
	
	
	
}


