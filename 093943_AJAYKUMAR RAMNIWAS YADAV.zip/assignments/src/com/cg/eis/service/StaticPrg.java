package com.cg.eis.service;

import java.util.HashSet;
import java.util.Set;

import com.cg.eis.bean.Employee;

public class StaticPrg {

	private static Set<Employee> obj;
	
	static Employee emp;
	
	static{
		obj=new HashSet<>();
		emp=new Employee(123,"sam",2400,"Manager","Medical Insurance");
		
		obj.add(emp);
		emp=new Employee(124,"raj",2560,"Clerk","Vehicle Insurance");
		obj.add(emp);
		
		
	}
	
	public static Set<Employee> getObj() {
		return obj;
	}

	public static void setObj(Set<Employee> obj) {
		StaticPrg.obj = obj;
	}

	public void addEmployee(Employee emp){
		obj.add(emp);
	}
	
	public int countTotEmployee(){
		return obj.size();
	}
	
	public void displayAllEmployee(){
		
		for (Object val:obj)
		{
			emp = (Employee)val;
			System.out.println(emp.toString());
		}
		
	};
	
	
	
}