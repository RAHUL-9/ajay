package com.cg.eis.service;

public interface IEmployeeService {
	
	
/*The services offered by this application currently are:
		i) Get employee details from user.
	ii) Find the insurance scheme for an employee based on salary and designation.
	iii) Display all the details of an employee.
*/
	
	public void addEmployee();
	public void findInsuranceScheme();
	public void getAllEmployee();
	
	
}
