package com.cg.eis.service;


	/*The services offered by this application currently are:
	i) Get employee details from user.
	ii) Find the insurance scheme for an employee based on salary and designation.
	iii) Display all the details of an employee.
*/

import java.util.Scanner;

//import com.capgemini.lab4.EmployeeFile;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.EmployeeValidater;

public class EmployeeServiceImpFile implements IEmployeeService {
	
	StaticPrg staticprg = new StaticPrg(); 
	EmployeeValidater val= new EmployeeValidater();
//	EmployeeFile empfile = new EmployeeFile();
	Scanner scan = new Scanner(System.in);
	Employee emp;
	static String empsalary;
	
	@Override
	public void addEmployee(){
		
		System.out.println("please enter how many Employee details you want to add");
		int num=scan.nextInt();
		if(num!=0 && num>0)
		{
			while(num>0)
			{

		System.out.println("Enter the following details:");
		System.out.println("Enter Employee id");
		long empid = scan.nextLong();
		System.out.println("Enter Employee Name");
		String empname = scan.next();
		new EmployeeServiceImp().acceptEmployeeSalary();
//		System.out.println("Enter Employee Salary");
//		empsalary = scan.nextDouble();

		System.out.println("Enter Employee Designation");
		String empdesignation = scan.next();
		System.out.println("Enter Employee Insurance Scheme");
		String empinsurancescheme = scan.nextLine();
		
		emp = new Employee(empid, empname, Double.parseDouble(empsalary), empdesignation, empinsurancescheme);
		staticprg.addEmployee(emp);
//		empfile.writeEmployee(emp.toStringFile());
		
		
		System.out.println("Employee details added successfully");

		num--;
			}}
	}
	
	public String acceptEmployeeSalary(){
		
		System.out.println("Enter Employee Salary");
		empsalary = scan.next();
		
		
	try{
		val.isEmployeeSalaryValid(String.valueOf(empsalary));
		
	}
	catch(EmployeeException exp){
		
		System.err.println(exp.getMessage());
		acceptEmployeeSalary();
	}
	return empsalary;
	}

	
	
	@Override
	public void findInsuranceScheme(){
		
		System.out.println("enter Insurance scheme name:");
		String empInsuranceScheme = scan.nextLine();

		for (Object val:StaticPrg.getObj())
		{

			emp = (Employee)val;
			if (empInsuranceScheme.equals(emp.toStringInsuranceScheme()))
			{
				System.out.println(emp.toString());
			}
		}
		
	}
	
	@Override
	public void getAllEmployee(){
		
		staticprg.displayAllEmployee();
		
	}


}
