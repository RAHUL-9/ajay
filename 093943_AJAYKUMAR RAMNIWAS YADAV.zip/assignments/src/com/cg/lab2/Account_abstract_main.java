package com.cg.lab2;

public class Account_abstract_main extends Account_abstract {
	
	public Account_abstract_main(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	public void withdraw(double amount,double balance)
	{
		double bal=balance;
		bal-= amount;
		System.out.println(bal);
	}

	public static void main(String[] args) {
		   	Person per1=new Person ("SMITH",21.0f);
	        Account_abstract acc1=new Account_abstract_main(4000.0,per1);
	        System.out.println(acc1+per1.getName());
	        acc1.withdraw(2000.0,acc1.getBalance());
	        
	       

	}

}
