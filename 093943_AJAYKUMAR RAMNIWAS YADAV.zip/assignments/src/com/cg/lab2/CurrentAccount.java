package com.cg.lab2;

public class CurrentAccount extends Account
{
	
	public CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}
	double bal2;
	final double overdraft=5000.0;
	public void withdraw(double amount)
	{
		if(amount>overdraft)
		{
			System.out.println("limit exceed");
			
		}
		else
		{
			bal2-=amount;
		}
	}
	public static void main(String[] args) {
		

	}

}
