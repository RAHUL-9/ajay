
package com.cg.lab2;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Person per1=new Person("SMITH",21.0f);
        Account acc1=new Account(2000.0,per1);
        System.out.println(acc1+per1.getName());
        
        Person per2=new Person("KATHY",22.0f);
        Account acc2=new Account(3000.0,per2);
       
        acc1.deposit(2000.0);
        acc2.withdraw(2000.0);
	}

}
