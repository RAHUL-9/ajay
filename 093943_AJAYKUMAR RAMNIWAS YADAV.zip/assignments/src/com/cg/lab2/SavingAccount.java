package com.cg.lab2;

public class SavingAccount extends Account
{
	
	public SavingAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		
	}
	double bal1;
	

	public final double minbal=500.0;
	public void withdraw(double amount)
	{
		if(bal1>=minbal+amount)
		{
			bal1-=amount;
			
		}
	}
	

}
