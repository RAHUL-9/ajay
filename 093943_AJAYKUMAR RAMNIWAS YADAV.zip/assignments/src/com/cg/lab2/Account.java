package com.cg.lab2;

public class Account
{
	private static int ctr;
	private long accNum;
	private double balance;
	private Person accHolder;
	
	public void deposit(double amount)
	{
		balance += amount; 
		System.out.println(balance);
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	public void withdraw(double amount)
	{
		balance -= amount;
		System.out.println(balance);
	}
	public double getBalance()
	{
		return balance;
	}

	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Account(double balance, Person accHolder) {
		
		ctr++;
		this.accNum = ctr;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	}

