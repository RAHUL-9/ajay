package com.cg.lab2;

import java.io.ObjectInputStream.GetField;

public class SavingAccountMain {

	public static void main(String[] args) {
		 Person per1=new Person("SMITH",21.0f);
		SavingAccount sa=new SavingAccount(3000.0,per1);
		sa.bal1=sa.getBalance();
		
		System.out.println(" Saving amount before withdrwal :"+sa.bal1);
		 Person per2=new Person("KATHY",22.0f);
		CurrentAccount ca=new CurrentAccount(4000.0,per2);
		ca.bal2=ca.getBalance();
		System.out.println(" Current amount before withdrwal :"+ca.bal2);
		sa.withdraw(2000);
		ca.withdraw(6000);
		System.out.println("Remaining balance in saving account after transaction is:"+sa.bal1);
		System.out.println("Remaining balance in current account after transaction is:"+ca.bal2);
		
		
	}

}
