package com.cg.lab3;

import java.util.Scanner;

import com.cg.std.excp.StudentException;


public class PersonMain {
	Scanner scan=new Scanner(System.in);
	PersonValidator pl=new PersonValidator();
	String fName = null;
	String lName=null;
	
	public String addFirstName()
	{ 
	
		System.out.println("Enter the First Name :");
		fName=scan.next();
		
		try
		{
		pl.isValidFirstName(fName);
		}
		catch(StudentException exp)
		{
			System.err.println(exp.getMessage());
			addFirstName();
		}
		return fName;
	}
	
	
	public String addLastName()
	{
		
		try
		{
		System.out.println("Enter the Last Name :");
		lName=scan.next();
		pl.isValidLastName(lName);
		}
		catch(StudentException exp)
		{
			System.err.println(exp.getMessage());
			addLastName();
		}
		return lName;
	}
	
	
	

	public static void main(String[] args) {
		
	
		PersonMain person=new PersonMain();
		System.out.println("Full Name :"+person.addFirstName()+" "+person.addLastName());
		//System.out.println(person.addLastName());
		

		
		
		
		
		

	}

}
