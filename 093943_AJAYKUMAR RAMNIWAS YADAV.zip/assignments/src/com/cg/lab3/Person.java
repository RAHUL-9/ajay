package com.cg.lab3;

public class Person {
	
	private String firstName;
	private String lastName;
	
	
	
	public void fullNameDisplay()
	{
		System.out.println("Full Name : "+firstName+" "+lastName);
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String fName) {
		this.firstName = fName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lName) {
		this.lastName = lName;
	}

}
