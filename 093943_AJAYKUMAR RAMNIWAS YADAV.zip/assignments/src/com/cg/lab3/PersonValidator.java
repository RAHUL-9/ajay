package com.cg.lab3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.std.excp.StudentException;

public class PersonValidator {
	
	public boolean isValidFirstName(String fName) throws StudentException
	{
		boolean flag=false;
		
		Pattern pat_fname=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher mat_fname=pat_fname.matcher(fName);
		if(!mat_fname.find())
		{
			throw new StudentException("please enter first name correctly");
		}
		return flag;
	}
	
	public boolean isValidLastName(String lName) throws StudentException
	{
		boolean flag=false;
		
		Pattern pat_lname=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher mat_lname=pat_lname.matcher(lName);
		
		if(!mat_lname.find())
		{
			throw new StudentException("please enter last name correctly");
		}
		return flag;
	}

}
