package com.cg.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class ProductArray {
	
	int num;
	int index;
	Scanner scan=new Scanner(System.in);
	
	String product[];
	
	public void addProduct()
	{
		System.out.println("Enter numbers of products you want to enter");
		num=scan.nextInt();
		product=new String[num];
		for(index=0;index<product.length;index++)
		{
			System.out.println("Enter the product names :");
			product[index]=scan.next();
		}
		System.out.println("Products names stored successfully.");
	}
	public void displaySortedProductName()
	{
		System.out.println("Products name after sorting :");
		Arrays.sort(product);
		for(String val:product)
		{
			System.out.println(val);
		}
	}
	
	
	public static void main(String  args[])
	{
		ProductArray pa=new ProductArray();
		pa.addProduct();
		pa.displaySortedProductName();
		
	}

}
