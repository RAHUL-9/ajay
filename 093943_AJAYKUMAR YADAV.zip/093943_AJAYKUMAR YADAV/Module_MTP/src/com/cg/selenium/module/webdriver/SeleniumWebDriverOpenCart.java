package com.cg.selenium.module.webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumWebDriverOpenCart 
{
	
	static String driverpath = "D:\\AJAYKUMAR 093943_IN\\VNV Software\\Selenium\\WebDrivers\\WebDriver_Java\\driver\\";

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url
		driver.navigate().to("https://demo.opencart.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//verify title
		String actual_title = driver.getTitle();
		String expected_title = "Your Store";
		boolean title=actual_title.equals(expected_title);
		if(title)
		{
			System.out.println("Page title Verified");
		}
		else 
		{
			System.out.println("Page title did not match");
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Click on '0 item(s)-$0.00' button
		driver.findElement(By.xpath("//*[@id='cart']/button")).click(); 
		
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//verify the dropdown message "Your Shopping cart is empty"
		String mesg=driver.findElement(By.className("text-center")).getText();
		if(mesg.equals("Your shopping cart is empty!"))
		{
			System.out.println("Dropdown message Verified");
		}
		else 
		{
			System.out.println("Dropdown message did not match");
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//click on currency
		driver.findElement(By.id("form-currency")).click();  
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//click on "Pound Streling Currency
		driver.findElement(By.name("GBP")).click(); 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//validating the selected currency
		String currencyelement=driver.findElement(By.id("form-currency")).getText();
		if(currencyelement.equals("� Currency "))
		{
			System.out.println("Selected currency is valid");
		}
		else
		{
			System.out.println("Selected currency is  invalid"); 
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//click on contact button 123456789
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[1]/a")).click(); 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//verify heading contact us
		String heading=driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
		if(heading.equals("Contact Us"))
		{
			System.out.println("Contact Us heading verified");
		}
		else
		{
			System.out.println("Contact Us heading did not match"); 
		} 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//verify default address
		String address=driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[1]/address")).getText();
		String phone=driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]")).getText();
		if(address.equals("Address 1") && phone.contains("123456789"))
		{
			System.out.println("Default address verified");
		}
		else
		{
			System.out.println("Default address did not match"); 
		}
		
		
		//Enter the name in "Your name" textbox
		driver.findElement(By.name("name")).sendKeys("Ajaykumar Yadav");
		
		//enter the invalid email address
		driver.findElement(By.name("email")).sendKeys("igate.c.n"); 
		
		//click on submit
		 driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
		
		//verifying error message  
		 try
		 {
			 String errormesg=driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[2]/div/div")).getText();
			 if(errormesg.equals("E-Mail Address does not appear to be valid!"))
			 {
				 System.out.println("Email address error message verified");
			 }
			 else
			 {
				 System.out.println("Email address error message did not match");
			 }
			 
		 }
		catch(Exception exp)
		 {
			System.err.println(exp.getMessage());
		 }
		
		 //enter valid email address
		 driver.findElement(By.name("email")).clear();
		 driver.findElement(By.name("email")).sendKeys("ajaykumar@capgemnini.com"); 
		 
		 //enter enquiry in text box
		 driver.findElement(By.id("input-enquiry")).sendKeys("your store enquiry"); 
		 
		 //click on submit button
		 driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
		 
		 //wait command
		 driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		 
		 //click on continue button
		 driver.findElement(By.linkText("Continue")).click();
		 
		 //click on 'Brands' under Extras
		 driver.findElement(By.linkText("Brands")).click();
		 
		 
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//verify title
			String actual_title1 = driver.getTitle();
			String expected_title1 = "Find Your Favorite Brand";
			boolean title1=actual_title1.equals(expected_title1);
			if(title1)
			{
				System.out.println("Page title Verified");
			}
			else 
			{
				System.out.println("Page title did not match");
			} 
		
		//click on sony link
		driver.findElement(By.linkText("Sony")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//validate the price '$1,202.00 Ex Tax:$1,000.00'
		//click on currency
		driver.findElement(By.id("form-currency")).click();  
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//click on "US Dollar" Currency
		driver.findElement(By.name("USD")).click(); 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String validatecurrency=driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[1]/p[2]")).getText();
		 if(validatecurrency.contains("$1,202.00"))
		 {
			 System.out.println("Price validated");
		 }
		 else
		 {
			 System.out.println("Price is not validated");
		 }
		 if(validatecurrency.contains("Ex Tax: $1,000.00"))
		 {
			 System.out.println("Tax validated");
		 }
		 else
		 {
			 System.out.println("Tax  is not validated");
		 }
				 
		 //add to cart 
		 driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		 
		 String msg=driver.findElement(By.xpath("//*[@id='product-manufacturer']/div[1]")).getText();
         System.out.println(msg);
	     if(msg.equals(" Success: You have added Sony VAIO to your shopping cart!\n�"))
	     {
	    	 System.out.println("Success message verified");
	    	 
	     }
	     else
	     {
	    	 System.out.println("Success message not verified");
	     }
		 
		 
		 //click on '1 item cart' //*[@id="cart"]/button
		 driver.findElement(By.xpath("//*[@id='cart']/button")).click();
		 
		 //verify item Sony VAIO
		 String itemverify=driver.findElement(By.linkText("Sony VAIO")).getText();
		 if(itemverify.equals("Sony VAIO"))
		 {
			 System.out.println("Item verified");
		 }
		 else
		 {
			 System.out.println("Item did not match");
		 }
				
		 driver.close();
		
		
}
}
